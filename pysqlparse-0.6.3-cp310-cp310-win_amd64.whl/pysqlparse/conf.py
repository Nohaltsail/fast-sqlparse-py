import os

__CURRENT_PATH__ = os.path.dirname(os.path.abspath(__file__))

DEFAULT_FORMAT_INDENT = 4
